
let roomStatus = {
    110: false,
    115: false,
    120: false,
    125: false,
    130: false,

    210: false,
    215: false,
    220: false,
    225: false,
    230: false
};

function showRooms() {

    let floor = document.getElementById("floor").value;
    let roomList = document.getElementById("rooms");

    roomList.innerHTML = "";

    if (floor === "") {
        return;
    }

    let start = floor === "1" ? 110 : 210;

    for (let i = 0; i < 5; i++) {

        let roomNumber = start + i * 5;

        let status = roomStatus[roomNumber];

        let room = document.createElement("div");

        room.className = "room";

        if (status === false) {
            room.innerHTML =
                "Room " + roomNumber +
                " : <span class='available'>Available</span>";
        }
        else {
            room.innerHTML =
                "Room " + roomNumber +
                " : <span class='unavailable'>Unavailable</span>";
        }

        roomList.appendChild(room);
    }

}

function bookAnother() {

    let floor = document.getElementById("floor").value;
    let message = document.getElementById("message");

    if (floor === "") {
        message.innerHTML = "Please select a floor first.";
        return;
    }

    let roomNumber = prompt("Please enter the room number:");

    if (roomNumber === null) {
        return;
    }

    roomNumber = Number(roomNumber);

    let firstRoom = floor === "1" ? 110 : 210;
    let lastRoom = floor === "1" ? 130 : 230;

    if (
        roomNumber < firstRoom ||
        roomNumber > lastRoom ||
        (roomNumber - firstRoom) % 5 !== 0
    ) {
        message.innerHTML = "Invalid room number.";
        return;
    }

    if (roomStatus[roomNumber] === true) {
        message.innerHTML = "This room is already unavailable.";
        return;
    }

    roomStatus[roomNumber] = true;

    message.innerHTML =
        "You have booked room: " + roomNumber;

    showRooms();

}
